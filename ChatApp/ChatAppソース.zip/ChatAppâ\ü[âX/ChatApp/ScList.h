#pragma once

#include "ScreenComponent.h"
#include "TextAlignment.h"
#include <string>
#include <map>

class ScList : public ScreenComponent
{
public:
	struct Item
	{
		std::string Text;
		int x;
		int y;
	};

public:
	ScList(unsigned int ColorFore, unsigned int ColorBack, Bound* bound, TextAlignment::Gravity gravity, int FontHandle, unsigned int ColorFrame);

public:
	void OnMouseMove(int x, int y) override;
	void OnMousePress(int x, int y) override;
	void Draw() const override;

	void AddItem(int ID, const std::string& Text);
	void RemoveItem(int ID);
	void RemoveAllItem();
	void ChangeText(int ID, const std::string& Text);
	void Alignment();
	const std::string& GetText(int ID) const;
	const std::map<int, Item>& GetItem() const;

protected:
	unsigned int m_ColorFore;
	unsigned int m_ColorBack;
	unsigned int m_ColorFrame;
	TextAlignment::Gravity m_Gravity;
	std::map<int, Item> m_Item;
	int m_FontHandle;
	int m_ItemYSize;
};
