#pragma once

#include "ScreenComponent.h"
#include <vector>
#include <map>

class Scene
{
public:
	Scene();
	virtual ~Scene();

public:
	virtual Scene* Update() = 0;
	virtual void Draw() = 0;

protected:
	void AddBaseComponent(ScreenComponent* component);
	void UpdateBase();
	void DrawBase() const;

	void UpdateComponent(std::vector<ScreenComponent*>& Component);
	void DrawComponent(const std::vector<ScreenComponent*>& Component) const;
	void DeleteComponent(std::vector<ScreenComponent*>& Component);

	void UpdateComponent(ScreenComponent*& Component);
	void DrawComponent(const ScreenComponent*& Component) const;
	void DeleteComponent(ScreenComponent*& Component);

private:
	std::vector<ScreenComponent*> m_BaseComponent;
};

inline void Scene::UpdateBase()
{
	UpdateComponent(m_BaseComponent);
}
inline void Scene::DrawBase() const
{
	DrawComponent(m_BaseComponent);
}
