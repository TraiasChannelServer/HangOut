#include "ScList.h"

ScList::ScList(unsigned int ColorFore, unsigned int ColorBack, Bound* bound, TextAlignment::Gravity gravity, int FontHandle, unsigned int ColorFrame)
	: ScreenComponent(bound)
	, m_ColorFore(ColorFore)
	, m_ColorBack(ColorBack)
	, m_ColorFrame(ColorFrame)
	, m_Gravity(gravity)
	, m_Item()
	, m_FontHandle(FontHandle)
	, m_ItemYSize()
{
	Alignment();
}

void ScList::OnMouseMove(int x, int y)
{
	// Do nothing
}

void ScList::OnMousePress(int x, int y)
{
	// Do nothing
}

void ScList::Draw() const
{
	if (m_Item.empty())
	{
		RECT r = m_Bound->GetRect();
		DrawBox(r.left, r.top, r.right, r.bottom, m_ColorFrame, TRUE);
		DrawBox(r.left + 1, r.top + 1, r.right - 1, r.bottom - 1, m_ColorBack, TRUE);
		DrawStringToHandle(r.left + 5, r.top + 1, "--List-is-empty--", m_ColorFore, m_FontHandle);
	}
	else
	{
		RECT r = m_Bound->GetRect();
		for (const auto& pair : m_Item)
		{
			DrawBox(r.left, r.top, r.right, r.bottom, m_ColorFrame, TRUE);
			DrawBox(r.left + 1, r.top + 1, r.right - 1, r.bottom - 1, m_ColorBack, TRUE);

			const Item& item = pair.second;
			DrawStringToHandle(item.x, item.y, item.Text.c_str(), m_ColorFore, m_FontHandle);

			OffsetRect(&r, 0, m_ItemYSize);
		}
	}
}

void ScList::AddItem(int ID, const std::string& Text)
{
	Item item = {Text};
	m_Item[ID] = item;
	Alignment();
}

void ScList::RemoveItem(int ID)
{
	m_Item.erase(ID);
	Alignment();
}

void ScList::RemoveAllItem()
{
	m_Item.clear();
	Alignment();
}

void ScList::ChangeText(int ID, const std::string& Text)
{
	m_Item[ID].Text = Text;
}

void ScList::Alignment()
{
	RECT r = m_Bound->GetRect();
	m_ItemYSize = r.bottom - r.top;

	for (auto& pair : m_Item)
	{
		Item& item = pair.second;
		RECT aligned = TextAlignment::Execute(item.Text, r, m_Gravity, m_FontHandle, 8);
		item.x = aligned.left;
		item.y = aligned.top;

		OffsetRect(&r, 0, m_ItemYSize);
	}
}

const std::string& ScList::GetText(int ID) const
{
	if (m_Item.count(ID) == 0)
	{
		static std::string ErrorText = "ErrorItem";
		return ErrorText;
	}

	return m_Item.at(ID).Text;
}

const std::map<int, ScList::Item>& ScList::GetItem() const
{
	return m_Item;
}
