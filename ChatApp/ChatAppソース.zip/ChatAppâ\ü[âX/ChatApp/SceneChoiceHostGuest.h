#pragma once

#include "Scene.h"

class SceneChoiceHostGuest : public Scene
{
public:
	SceneChoiceHostGuest();

public:
	Scene* Update() override;
	void Draw() override;

private:
	void BeHost();
	void BeGuest();
	void End();

private:
	Scene* m_Next;
};

