#pragma once

#include "ScLabel.h"
#include "DelegateArg.h"
#include <string>
#include <memory>

class ScToggle : public ScLabel
{
public:
	ScToggle(unsigned int ColorFore, unsigned int ColorBack, Bound* bound, int FontHandle,
		DelegateArgBase<bool>* Callback);

public:
	void OnMouseMove(int x, int y) override;
	void OnMousePress(int x, int y) override;
	void Draw() const override;

protected:
	bool m_Hover;
	int m_PressCount;
	int m_Padding;
	bool m_OffOn;
	std::unique_ptr<DelegateArgBase<bool>> m_Callback;
};
