#pragma once

#include "Bound.h"
#include <memory>

class ScreenComponent
{
public:
	ScreenComponent();
	ScreenComponent(Bound* bound);
	virtual ~ScreenComponent() = default;

public:
	virtual void OnMouseMove(int x, int y) = 0;
	virtual void OnMousePress(int x, int y) = 0;
	virtual void Draw() const = 0;

protected:
	std::unique_ptr<Bound> m_Bound;
};

inline ScreenComponent::ScreenComponent()
	: m_Bound()
{
}
inline ScreenComponent::ScreenComponent(Bound* bound)
	: m_Bound(bound)
{
}
