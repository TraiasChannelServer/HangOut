#pragma once

#include "ScreenComponent.h"
#include "TextAlignment.h"
#include <string>

class ScLabel : public ScreenComponent
{
public:
	ScLabel(const std::string& Text, unsigned int ColorFore, int x, int y, int FontHandle);
	ScLabel(const std::string& Text, unsigned int ColorFore, unsigned int ColorBack, int x, int y, int FontHandle);
	ScLabel(const std::string& Text, unsigned int ColorFore, unsigned int ColorBack, Bound* bound, TextAlignment::Gravity gravity, int FontHandle);
	virtual ~ScLabel() = default;

public:
	virtual void OnMouseMove(int x, int y) override;
	virtual void OnMousePress(int x, int y) override;
	virtual void Draw() const override;

	void ChangeText(const std::string& Text);
	const std::string& GetText() const;

protected:
	void FitBound();

protected:
	std::string m_Text;
	unsigned int m_ColorFore;
	unsigned int m_ColorBack;
	bool m_BkColorTransparent;
	TextAlignment::Gravity m_Gravity;
	int m_TextX;
	int m_TextY;
	int m_FontHandle;
	bool m_FitBoundMode;
};

inline const std::string& ScLabel::GetText() const
{
	return m_Text;
}