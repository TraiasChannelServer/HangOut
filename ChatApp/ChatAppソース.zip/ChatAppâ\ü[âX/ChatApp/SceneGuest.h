#pragma once

#include "Scene.h"
#include "ScLabel.h"
#include "ScList.h"
#include <string>

class SceneGuest : public Scene
{
private:
	enum class ConnectStep
	{
		OFF,
		WAIT_ACCEPT,
		ON
	};

	static const char CONNECT_STEP_STATE[][64];

public:
	SceneGuest();
	~SceneGuest();

public:
	Scene* Update() override;
	void Draw() override;

private:
	void SetIP1(std::string& IP);
	void SetIP2(std::string& IP);
	void SetIP3(std::string& IP);
	void SetIP4(std::string& IP);
	void SetPortNum(std::string& Port);
	void SetName(std::string& Name);
	void TryConnect();
	void Disconnect();
	void End();

private:
	Scene* m_Next;
	IPDATA m_IP;
	int m_Port;
	std::string m_Name;

	ConnectStep m_ConnectStep;
	ScLabel* m_ConnectState;
	int m_NetHandle;
	ScLabel* m_HostName;
	ScList* m_ConnectingGuest;
};