#pragma once

#include "Scene.h"

class SceneCreator
{
public:
	enum class Name
	{
		CHOICE_HOST_GUEST,
		HOST,
		GUEST
	};

public:
	static Scene* Create(Name name);

private:
	SceneCreator() = delete;
};