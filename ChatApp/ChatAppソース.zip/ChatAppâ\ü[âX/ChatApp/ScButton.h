#pragma once

#include "ScLabel.h"
#include "DelegateVoid.h"
#include <string>
#include <memory>

class ScButton : public ScLabel
{
private:
	static constexpr int FRAME_WIDTH_RELEASE = 2;
	static constexpr int FRAME_WIDTH_PRESS = 3;

public:
	ScButton(const std::string& Text, unsigned int ColorFore, unsigned int ColorBack, int x, int y, int FontHandle,
		unsigned int ColorFrame, unsigned int ColorBackHover, unsigned int ColorBackPress, DelegateVoidBase* Callback);
	ScButton(const std::string& Text, unsigned int ColorFore, unsigned int ColorBack, Bound* bound, TextAlignment::Gravity gravity, int FontHandle,
		unsigned int ColorFrame, unsigned int ColorBackHover, unsigned int ColorBackPress, DelegateVoidBase* Callback);

public:
	void OnMouseMove(int x, int y) override;
	void OnMousePress(int x, int y) override;
	void Draw() const override;

protected:
	unsigned int m_ColorFrame;
	unsigned int m_ColorBackHover;
	unsigned int m_ColorBackPress;
	bool m_Hover;
	int m_PressCount;
	std::unique_ptr<DelegateVoidBase> m_Callback;
};
